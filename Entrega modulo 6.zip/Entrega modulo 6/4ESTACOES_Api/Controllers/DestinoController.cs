﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure.Internal;
using 4ESTACOES_Api.Models;

namespace 4ESTACOES_Api.Controllers
{
	[Route("api/[controller]")]
	[ApiController]
	public class DestinoController : ControllerBase
	{
		private readonly DestinoDBContext _context;

		public DestinoController(DestinoDBContext context)
		{
			_context = context;
		}

		// GET: api/Destinos - LISTA TODOS OS DESTINOS
		[HttpGet]
		public IEnumerable<Destino> GetDestino()
		{ return _context.Destino;
		}

		// GET: api/Destinos/id - LISTA DESTINO POR ID
		[HttpGet("{id}")]
		public IActionResult GetDestinoPorId(int id)
		{
			Destino destino = _context.Destino.SingleOrDefault(modelo => modelo.DestinoId == id);
			if (destino == null)
			{
				return NotFound();
			}
			return new ObjectResult(destino);
		}

       // ATUALIZA UM DESTINO 
		[HttpPut("{id}")]
		public IActionResult AtualizaDestino(int id, Destino item)
		{
			if (id != item.DestinoId)
			{
				return BadRequest();
			}
			_context.Entry(item).State = EntityState.Modified;//Verifica se realmente houve modificações no objeto
			_context.SaveChanges();

			return new NoContentResult();
		}

		// APAGA UM DESTINO POR ID
		[HttpDelete("{id}")]
		public IActionResult DeletaDestino(int id)
		{
			var destino = _context.Destino.SingleOrDefault(m => m.DestinoId == id);

			if (destino == null)
			{
				return BadRequest();
			}

			_context.Destino.Remove(destino);
			_context.SaveChanges();
			return Ok(destino);
		}

	}
}

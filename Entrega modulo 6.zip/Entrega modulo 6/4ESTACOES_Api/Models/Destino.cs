﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;


namespace 4ESTACOES_Api.Models
{
	[Table("Destino")]
	public class Destino
	{
		[Key]
		public int DestinoId { get; set; }
		[Required(ErrorMessage = "Informe o local do Destino")]
		[StringLength(100)]
		public string Local { get; set; }
		[Required(ErrorMessage = "Informe o valor do Destino")]
		public int ValorDestino { get; set; }
	}
}



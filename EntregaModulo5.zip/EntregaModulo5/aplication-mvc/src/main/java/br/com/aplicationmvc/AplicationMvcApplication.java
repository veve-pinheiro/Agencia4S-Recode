package br.com.aplicationmvc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AplicationMvcApplication {

	public static void main(String[] args) {
		SpringApplication.run(AplicationMvcApplication.class, args);
	}

}

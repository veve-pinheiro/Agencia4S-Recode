package br.com.aplicationmvc.model;

public class Reserva {
	
	private String nome;
	private String email;
	private int cel;
	private String destino;
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public int getCel() {
		return cel;
	}
	public void setCel(int cel) {
		this.cel = cel;
	}
	public String getDestino() {
		return destino;
	}
	public void setDestino(String destino) {
		this.destino = destino;
	}
	
	

}
